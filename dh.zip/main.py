#imports
import discord
import requests
import asyncio
import math
from udpy import UrbanClient
import json
from discord.ext.commands import Bot
from random import randint
import random
from discord.ext import commands
import configparser
import os
import platform
import html
import time
from colour import Color
from PyDictionary import PyDictionary
from misc import get_all_values, makec
from sudoku import generate_sudoku
from sudoku import print_matrix
from discord_slash import SlashCommand
import datetime
from misc import need_perms
from misc import CustomEmbedPaginator
from art import Clock
from art import Server
from ascii import convert_image_to_ascii, convert_image_to_blocks
from keep_alive import keep_alive
#important variables

intents = discord.Intents.all()
intents.members = True
me = [511025033976741889]
client = Bot(command_prefix=commands.when_mentioned_or("fi ", "fiona ", "FI ", "Fiona ", "Fi "), intents=intents)
dictionary=PyDictionary()
config = configparser.RawConfigParser()
slash = SlashCommand(client, override_type=True, sync_commands=True, sync_on_cog_reload=True)
ud = UrbanClient()

#cogs
client.load_extension("social")
client.load_extension("economy")
client.load_extension("reminders")
client.load_extension("slashes")
client.load_extension("akin")
client.load_extension("jessica")
client.load_extension("snipe")


#colors for embeds, pink and red because I like to swtich them around sometimes
pink = 0xFF8CC4
pinkstr = "FF8CC4"
red = 0xF43D38
redstr = "F43D38"
cola = red

async def status_task():
  while True:
    await client.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="{} servers".format(str(len(client.guilds)))))
    await asyncio.sleep(30)
    await client.change_presence(activity=discord.Game("fi help"))
    await asyncio.sleep(30)

@client.event
async def on_message(message):
  if (message.guild.id == 844585426210521108):
    print("hi")
    with open('smh.txt', 'a') as f:
      f.write("{}: {}\n".format(message.author ,message.content))
  if "https://discord-app.co.uk/" in message.content:
    await message.channel.purge(limit=1)
    await message.channel.send("don't send that link pls")
    await message.channel.purge(limit=1)
  try:
    i = int(message.content)
    with open('data2.json', 'r') as f:
      servers = json.load(f)
      if servers["{}".format(message.guild.id)]["count"][0] == str(message.channel.id):
        if (i == (servers["{}".format(message.guild.id)]["count"][1]+1)) and ("{}".format(message.author.id) != (servers["{}".format(message.guild.id)]["count"][2])):
          await message.add_reaction("🟢")
          Server.new_number(message.guild, True, message.author)					
        else:
          await message.add_reaction("🔴")
          Server.new_number(message.guild, False, message.author)
          await message.channel.send("{} ruined it at {}. Restart at 0!".format(message.author.mention, servers["{}".format(message.guild.id)]["count"][1]))
  except Exception:
    pass
  await client.process_commands(message)

@client.event
async def on_ready():
  print("Logged in as " + client.user.name)
  print("Discord.py API version:", discord.__version__)
  print("Python version:", platform.python_version())
  print("Running on:", platform.system(), platform.release(), "(" + os.name + ")")

@client.event
async def on_guild_join(guild):
  try:
    await guild.system_channel.send(embed=await show_help(guild.system_channel, ()))
  except Exception:
    await guild.text_channels[0].send(embed=await show_help(guild.text_channels[0], ()))

@client.command(name="info")
async def info(ctx):
  client.appinfo = await client.application_info()
  embed = discord.Embed(description="Here you go!", color=cola, title="Fiona Bot Information")
  embed.set_thumbnail(url=client.appinfo.icon_url)
  embed.add_field(name="Owner", value=client.appinfo.owner, inline=True)
  embed.add_field(name="Prefix", value="fi ", inline=True)
  embed.add_field(name="Name", value=client.appinfo.name, inline=True)
  embed.add_field(name="Servers", value=str(len(client.guilds)), inline=True)
  embed.add_field(name="Users", value=str(len(client.users)), inline=True)
  embed.add_field(name="Public", value=client.appinfo.bot_public, inline=True)
  embed.set_footer(text="Requested by {0}".format(ctx.message.author))
  embed.timestamp = (datetime.datetime.utcnow())
  await ctx.send(embed=embed)

@client.command(name="serverinfo", aliases=["server"])
async def serverinfo(ctx):
  server = ctx.guild
  embed = discord.Embed(description="%s " % (str(server)), timestamp=datetime.datetime.utcnow(), title="Server Information", color=cola)
  embed.set_thumbnail(url=server.icon_url)
  embed.add_field(name="Owner", value=str(server.owner), inline=True)
  embed.add_field(name="Member Count", value="{} members".format (server.member_count), inline=True)
  embed.add_field(name="Categories", value="{} categories".format (len(server.categories)), inline=True)		
  embed.add_field(name="Channels", value="{} channels".format (len(server.text_channels)+ len(server.voice_channels)), inline=True)
  embed.add_field(name="Default Role", value=str(server.default_role), inline=True)
  embed.add_field(name="Date Created", value=(str(server.created_at).split(" ")[0]), inline=True)
  try:
    embed.add_field(name="Timezone", value="{}".format(Clock.get_time_server(server)), inline=True)
  except Exception:
    pass	
  embed.add_field(name="Roles (%s)" % str(len([x.name for x in server.roles])), value=', '.join([str(x) for x in server.roles]), inline=False)
  await ctx.send(embed=embed)

@client.command()
async def userinfo(ctx, *, member: discord.Member=None):
  if not member:
    member = ctx.message.author
  embed = discord.Embed(description=str(member), color=cola, timestamp=datetime.datetime.utcnow(), title="User Information")
  embed.add_field(name="Displayed Name", value=str(member.display_name), inline=True)
  embed.add_field(name="Date Joined Discord (UTC)", value=str(member.created_at.strftime("%A, %B %d %Y @ %H:%M:%S %p")), inline=False)
  embed.add_field(name="Date Joined Server (UTC)", value=str(member.joined_at.strftime("%A, %B %d %Y @ %H:%M:%S %p")), inline=False)
  embed.add_field(name="Top Role", value=str(member.top_role), inline=False)
  embed.add_field(name="Timezone", value="{}".format(Clock.get_time_user(member)), inline=False)		
  embed.set_thumbnail(url=member.avatar_url)
  embed.set_footer(text="Requested by {0}".format(ctx.message.author))
  await ctx.send(embed=embed)

@client.command(name="ping", pass_ctx=True)
async def ping(ctx):
  embed = discord.Embed(color=cola)
  embed.set_footer(text="Requested by {0}".format(ctx.message.author))
  embed.add_field(name="Pong!", value="{0}ms".format(round(client.latency*1000)), inline=True)
  await ctx.send(embed=embed)

@client.command(pass_ctx=True)
async def plonk(ctx):
  before = time.monotonic()
  message = await ctx.send("Pong!")
  ping = (time.monotonic() - before) * 1000
  before = time.monotonic()
  await message.edit(content=f"Send:  `{int(ping)}ms`")
  edit = (time.monotonic() - before) * 1000
  await ctx.send(content=f"Edit:  `{int(edit)}ms`")
  print(f"Ping {int(ping)}ms")

@client.command(name="invite", pass_ctx=True)
async def invite(ctx):
  await ctx.send("I sent you a private message! Go check your DMs")
  await ctx.message.author.send("Invite me by clicking here: https://discord.com/api/oauth2/authorize?client_id=736372330644897893&permissions=8&scope=bot%20applications.commands")

@client.command(name="joinserver", pass_ctx=True)
async def server(ctx):
  await ctx.send("I sent you a private message! Go check your DMs")
  await ctx.message.author.send("Join my discord server by clicking here: https://discord.gg/5ja68Pz9dq")

@client.command(name="fact", pass_ctx=True, aliases=["funfact", "facts"])
async def fact(ctx):
  lines = open("afile.txt").read().splitlines()
  myline =random.choice(lines)
  await ctx.send(myline)
  print(myline)

@client.command(name="poll", pass_ctx=True)
async def poll(ctx, *args):
  mesg = " ".join(args)
  embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title="{0}".format(mesg), description=" -- ", color=cola)
  embed.set_footer(text="Poll created by: {0} • React to vote!".format(ctx.message.author))
  embed_message = await ctx.send(embed=embed)
  await embed_message.add_reaction("👍")
  await embed_message.add_reaction("👎")

@client.command(name="8ball", pass_ctx=True, aliases=["8b", "8", "8bal"])
async def eight_ball(ctx, *args):
  mesg = " ".join(args)
  if mesg == "":
    mesg = "..."
  answers = ["It is certain.", "It is decidedly so.", "You may rely on it.", "Without a doubt.", "Yes - definitely.", "As I see, yes.", "Most likely.", "Outlook good.", "Yes.", "Signs point to yes.", "Reply hazy, try again.", "Ask again later.", "Better not tell you now.", "Cannot predict now.", "Concentrate and ask again later.", "Don\"t count on it.", "My reply is no.", "My sources say no.", "Outlook not so good.", "Very doubtful."]
  embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title=mesg, description="{0}".format(answers[randint(0, len(answers))]), color=cola)
  embed.set_footer(text="Question asked by: {0} • Ask your own now!".format(ctx.message.author))
  await ctx.send(embed=embed)
    
@client.command(name="say", pass_ctx=True, aliases=['embed, echo'])
async def embed(ctx, *args):
  mesg = " ".join(args)
  if mesg == "":
    return
  else:
    embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title="", description=mesg, color=cola)
    embed.set_footer(text="Originally said by: {0}".format(ctx.message.author))
    await ctx.send(embed=embed)

@client.command(name="colour", pass_ctx=True, aliases=["color"])
async def color(ctx, *args):
  mesg = " ".join(args)
  uppercase = mesg.upper()
  c = Color(mesg)
  preview = "https://dummyimage.com/600x600/{}/ffffff.png&text={}".format(c.hex[1:], uppercase)
  print(preview)
  embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title="{} ".format(mesg.upper()), description="some info about {}...".format(c), color=cola)
  embed.add_field(name="HEX", value=c.hex, inline=False)
  embed.add_field(name="HSL", value="{}".format(c.hsl), inline=False)
  embed.add_field(name="RGB", value="{}".format(c.rgb), inline=False)
  embed.set_thumbnail(url=preview)
  embed.set_footer(text="Requested by: {0}".format(ctx.message.author))
  await ctx.send(embed=embed)

@client.command(name='bmi', pass_context=True)
async def bmi(context, *args):
  ebed = discord.Embed(title='**Weight** ', description='What is your weight in kg?', color=cola)
  ebed.set_footer(text='Requested by: {0}'.format(context.message.author))
  await context.message.channel.send(embed=ebed)
  def check(m):
    return m.author == context.message.author and m.channel == context.message.channel
  try:
    msg = await client.wait_for("message", check=check, timeout=30)
  except TimeoutError:
    return await context.message.channel.send("Timed out, try again.")
  w = int(msg.content)
  eed = discord.Embed(title='**Height** ', description='What is your height in cm?', color=cola)
  eed.set_footer(text='Requested by: {0}'.format(context.message.author))
  await context.message.channel.send(embed=eed)
  try:
    mg = await client.wait_for("message", check=check, timeout=30)
  except TimeoutError:
    return await context.message.channel.send("Timed out, try again.")
  h = int(mg.content)
  bmi = w / (h ** 2) * 10000
  BMI = (round(bmi,2))
  ebed = discord.Embed(title='**BMI** ', description='Your BMI is {}'.format (BMI), color=cola)
  ebed.set_footer(text='Requested by: {0}'.format(context.message.author))
  await context.message.channel.send(embed=ebed)
  if(bmi <= 18.5):
    fat = "underweight"
  elif(bmi > 18.5 and bmi <= 24.9):
    fat = ("normal weight")
  elif(bmi > 24.9 and bmi <= 29.9):
    fat = ("overweight")
  else:
    fat = ("obesity")
  ebd = discord.Embed(title='**BMI** ', description='The classification of your BMI is {}'.format (fat), color=cola)
  ebd.set_footer(text='Requested by: {0}'.format(context.message.author))
  await context.message.channel.send(embed=ebd)

triviatimes = 0
@client.command(name="trivia", pass_ctx=True)
@commands.cooldown(1, 5, commands.BucketType.user)
async def trivia(ctx, *args):
  global triviatimes
  count = " ".join(args)
  if count == "count":
    await ctx.send(triviatimes)
  else:
    triviatimes += 1
    r = requests.get("https://opentdb.com/api.php?amount=1&type=multiple")
    data = json.loads(r.text)
    question = data["results"][0]["question"]
    answers = data["results"][0]["incorrect_answers"]
    correct_answer = data["results"][0]["correct_answer"]
    answers.append(correct_answer)
    random.shuffle(answers)
    print (correct_answer)
    a = answers[0]
    b = answers[1]
    c = answers[2]
    d = answers[3]
    embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title="Trivia Time! ", description = (html.unescape(question)), color=cola)
    embed.add_field(name="a) {}".format(html.unescape(a)), value = "type a", inline = False)
    embed.add_field(name="b) {}".format(html.unescape(b)), value = "type b", inline = False)
    embed.add_field(name="c) {}".format(html.unescape(c)), value = "type c", inline = False)
    embed.add_field(name="d) {}".format(html.unescape(d)), value = "type d", inline = False)
    embed.set_footer(text="Requested by: {0}".format(ctx.message.author))
    await ctx.send(embed=embed)
    def check(m):
      return m.author == ctx.message.author and m.channel == ctx.message.channel
    try:
      mssag = await client.wait_for("message", check=check, timeout=30)
    except asyncio.TimeoutError:
      await ctx.send("Timed out, try running this command again.")
      return
    useranswer = mssag.content.lower()
    if useranswer == "a":
      user_answer = answers[0]
    if useranswer == "b":
      user_answer = answers[1]
    if useranswer == "c":
      user_answer = answers[2]
    if useranswer == "d":
      user_answer = answers[3]
    if user_answer == correct_answer:
      await ctx.send("YAY! you got it right! Thanks for playing!")
    if user_answer != correct_answer:
      print (user_answer)
      await ctx.send("Sorry, that is incorrect. Correct answer is {}. Thanks for playing tho :)".format(html.unescape(correct_answer)))

@client.command(name="dmoj", pass_ctx=True)
async def dmoj(ctx, *args):
  username = " ".join(args)
  r = requests.get("https://dmoj.ca/api/user/info/{}".format(username))
  data = json.loads(r.text)
  print(data)
  points = data["points"]
  performance = data["performance_points"]
  rank = data["rank"]
  solved = data["solved_problems"]
  rating = data["contests"]["current_rating"]
  embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title="{}".format(username), description = ("DMOJ user"), color=cola)
  embed.add_field(name="Points", value = points, inline = False)
  embed.add_field(name="Performance Points", value = performance, inline = False)
  embed.add_field(name="Rank", value = rank, inline = False)
  embed.add_field(name="Solved Problems", value = len(solved), inline = False)
  embed.add_field(name="Current Rating", value = rating, inline = False)
  embed.set_footer(text="Requested by: {0}".format(ctx.message.author))
  await ctx.send(embed=embed)

@client.command(name="checkword", pass_ctx=True, aliases=["check"])
async def checkword(ctx, *args):
  checkword = ' '.join(args)
  defins = dictionary.meaning(checkword)
  try: 
    list(defins.values())
    await ctx.send("Yep, that's a word")
  except AttributeError:
    await ctx.send("Sorry, I don't think that's a word...")

@client.command(name="define", pass_ctx=True, aliases=["english", "en", "definition"])
async def define(ctx, *args):
  word = " ".join(args)
  defins = dictionary.meaning(word)
  definitions = list(get_all_values(defins))
  embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title=word.upper(), color=cola)
  count = 0
  try: 
    for index in range(0, len(definitions)):
      count += 1
      embed.add_field(name = "{}) {}".format(count, definitions[index]), value = "...", inline = False)
    await ctx.send(embed=embed)
  except AttributeError or IndexError:
    await ctx.send("Sorry, I don't know the meaning of that")

@client.command(name="urbandictionary", pass_ctx=True, aliases=["urban", "urb", "ud"])
async def urbandictionary(ctx, *args):
  word = " ".join(args)
  defs = ud.get_definition(word)
  if len(defs) == 0:
    await ctx.send("Sorry, I don't know the meaning of that")
    return
  out = ""
  embeds = []
  for d in defs:
    out += ((d.definition.replace("[", "").replace("]", "")) + "\n")
  for i in range(math.ceil(len(out)/2048)):
    if i == (math.ceil(len(out)/2048) - 1):
      embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title=word.upper(), color=cola, description = out[i*2048:])
      embed.set_footer(text="Page {} of {}".format(i+1, math.ceil(len(out)/2048)))
    else:
      embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title=word.upper(), color=cola, description = out[i*2048:i+2048])
    embed.set_footer(text="Page {} of {}".format(i+1, math.ceil(len(out)/2048)))
    embeds.append(embed)
  if len(embeds) > 1:
    paginator = CustomEmbedPaginator(ctx, len(embeds))
    paginator.add_reaction('⏮️', "first")
    paginator.add_reaction('⏪', "back")
    paginator.add_reaction('⏩', "next")
    paginator.add_reaction('⏭️', "last")
    await paginator.run(embeds, 0)
  elif len(embeds) == 1:
    await ctx.send(embed=embeds[0])
  

@client.command(name="synonym", pass_ctx=True, aliases=["sy", "syn", "synonyms"])
async def synonyms(ctx, *args):
  word = " ".join(args)
  defins = dictionary.synonym(word)
  definitions = list(get_all_values(defins))
  embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title=word.upper(), color=cola)
  count = 0
  try: 
    for index in range(len(definitions)):
      count += 1
      embed.add_field(name = "{}) {}".format(count, definitions[index]), value = "...", inline = True)
    await ctx.send(embed=embed)
  except AttributeError or IndexError:
    await ctx.send("Sorry, I don't know the meaning of that")

@client.command(name="purge", pass_ctx=True)
async def purge(ctx, number):
  if ctx.message.author.guild_permissions.manage_messages:
    numberr = int(number)+1
    await ctx.message.channel.purge(limit=numberr)
    await asyncio.sleep(2)
    embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title="Chat Cleared!", description="{} cleared {} messages!".format(ctx.message.author, number), color=cola)
    message = await ctx.send(embed=embed)
    await asyncio.sleep(3)
    await message.delete()
  else:
    await need_perms(ctx, cola)

@client.command(name="calendar", pass_ctx=True, aliases = ["monthcalendar", "cal"])
async def calendar(ctx):
  def is_correct(m):
    return m.author == ctx.message.author
  try:
    embed = discord.Embed(description="Step 1", color=cola, timestamp=datetime.datetime.utcnow(), title="Monthly Calendar")
    embed.add_field(name="Enter the year", value="Format: yyyy, this year would be 2021\nCommand will be cancelled after 30 seconds if nothing is sent", inline=True)
    embed.set_footer(text="Requested by {0}".format(ctx.message.author))
    first = await ctx.send(embed=embed)
    msg = await client.wait_for("message", check=is_correct, timeout=30)
    year = int(msg.content)
    if 0 > year:
      raise TypeError
  except asyncio.TimeoutError:
    embed = discord.Embed(description="Step 1", color=cola, timestamp=datetime.datetime.utcnow(), title="Monthly Calendar")
    embed.add_field(name="Enter the year", value="Timed out, try running this command again", inline=True)
    embed.set_footer(text="Requested by {0}".format(ctx.message.author))
    await first.edit(embed=embed)
    return
  except TypeError:
    embed = discord.Embed(description="Step 1", color=cola, timestamp=datetime.datetime.utcnow(), title="Monthly Calendar")
    embed.add_field(name="Enter the year", value="Your input can only be in the form of a number no less than 0. Try again", inline=True)
    embed.set_footer(text="Requested by {0}".format(ctx.message.author))
    await first.edit(embed=embed)
    return
  try:
    embed = discord.Embed(description="Step 2", color=cola, timestamp=datetime.datetime.utcnow(), title="Monthly Calendar")
    embed.add_field(name="Enter the month", value="Format: mm, May would be 05 or 5\nCommand will be cancelled after 30 seconds if nothing is sent", inline=True)
    embed.set_footer(text="Requested by {0}".format(ctx.message.author))
    second = await ctx.send(embed=embed)
    msg = await client.wait_for("message", check=is_correct, timeout=30)
    month = int(msg.content)
    if month > 12 or month < 0:
      raise TypeError
  except asyncio.TimeoutError:
    embed = discord.Embed(description="Step 2", color=cola, timestamp=datetime.datetime.utcnow(), title="Monthly Calendar")
    embed.add_field(name="Enter the month", value="Timed out, try running this command again", inline=True)
    embed.set_footer(text="Requested by {0}".format(ctx.message.author))
    await second.edit(embed=embed)
    return
  except TypeError:
    embed = discord.Embed(description="Step 2", color=cola, timestamp=datetime.datetime.utcnow(), title="Monthly Calendar")
    embed.add_field(name="Enter the month", value="Your input can only be in the form of a number from 1 to 12, try running this command again", inline=True)
    embed.set_footer(text="Requested by {0}".format(ctx.message.author))
    await second.edit(embed=embed)
    return
  embed = discord.Embed(description="{}```".format(makec(year, month)[1]), color=cola, timestamp=datetime.datetime.utcnow(), title=makec(year, month)[0])
  embed.set_footer(text="Requested by {0}".format(ctx.message.author))
  await ctx.send(embed=embed)

@client.command()
@commands.cooldown(1, 5, commands.BucketType.user)
async def sudoku(ctx):
  def is_correct(m):
    return m.author == ctx.message.author
  try:
    embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title="Sudoku", description="Step 1", color=cola)
    embed.add_field(name="Please enter the rows of the sudoku. Use zero '0' for empty fields. No spaces. Shift-Enter for new line.", value = "Example: \n300200000\n000107000\n706030500\n070009080\n900020004\n010800050\n009040301\n000702000\n000008006\n\nCommand will be cancelled after 10 minutes if nothing is sent", inline = False)
    embed.set_footer(text="Requested by: {0}".format(ctx.message.author))
    first = await ctx.send(embed=embed)
    msg = await client.wait_for("message", check=is_correct, timeout=600)
  except asyncio.TimeoutError:
    embed = discord.Embed(description="Step 1", color=cola, timestamp=datetime.datetime.utcnow(), title="Sudoku")
    embed.add_field(name="Please enter the rows of the sudoku. Use zero '0' for empty fields. No spaces. Shift-Enter for new line.", value = "Timed out, try running this command again", inline = False)
    embed.set_footer(text="Requested by {0}".format(ctx.message.author))
    await first.edit(embed=embed)
    return
  except TypeError:
    embed = discord.Embed(description="Step 1", color=cola, timestamp=datetime.datetime.utcnow(), title="Sudoku")
    embed.add_field(name="Please enter the rows of the sudoku. Use zero '0' for empty fields. No spaces. Shift-Enter for new line.", value = "Example: \n300200000\n000107000\n706030500\n070009080\n900020004\n010800050\n009040301\n000702000\n000008006\n\nCommand will be cancelled after 10 minutes if nothing is sent", inline = False)
    embed.set_footer(text="Requested by {0}".format(ctx.message.author))
    await first.edit(embed=embed)
    return
  inp = msg.content
  sudoku = list(range(9))
  for i in range(9):
    sudoku[i] = list(list(map(str,inp.split("\n")))[i])
    sudoku[i] = [int(item) for item in sudoku[i]]
  embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title="Sudoku", description="Here's the board", color=cola)
  embed.add_field(name="Calculating...", value="```{}```".format(print_matrix(sudoku, 0, "")), inline=True)
  embed.set_footer(text="Requested by: {0}".format(ctx.message.author))
  await ctx.send(embed=embed)
  embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title="Sudoku", description="Hope this helps!", color=cola)
  embed.add_field(name="Answer Key", value="```{}```".format(generate_sudoku(sudoku)), inline=True)
  embed.set_footer(text="Requested by: {0}".format(ctx.message.author))
  await msg.reply(embed=embed)

@client.command()
@commands.cooldown(1, 5, commands.BucketType.user)
async def ascii(ctx, *args):
  reverse = False
  def is_correct(m):
    return m.author == ctx.message.author
  if " ".join(args) == "dark":
    reverse = True
  try:
    embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title="Ascii Art", description="Step 1", color=cola)
    embed.add_field(name="Image", value = "Send the image you want to convert into ascii art\nCommand will be cancelled after 5 minutes if nothing is sent", inline = False)
    embed.set_footer(text="Requested by: {0}".format(ctx.message.author))
    first = await ctx.send(embed=embed)
    msg = await client.wait_for("message", check=is_correct, timeout=300)
  except asyncio.TimeoutError:
    embed = discord.Embed(description="Step 1", color=cola, timestamp=datetime.datetime.utcnow(), title="Ascii Art")
    embed.add_field(name="Image", value = "Timed out, try running this command again", inline = False)
    embed.set_footer(text="Requested by {0}".format(ctx.message.author))
    await first.edit(embed=embed)
    return
  image = msg.attachments[0].url
  out = convert_image_to_ascii(image, reverse=reverse)
  print(out)
  embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title="Ascii Art", description="{}".format(out), color=cola)
  embed.set_footer(text="Requested by: {0}".format(ctx.message.author))
  await ctx.send(embed=embed)

@client.command()
@commands.cooldown(1, 5, commands.BucketType.user)
async def block(ctx, *args):
  red = False
  def is_correct(m):
    return m.author == ctx.message.author
  if " ".join(args) == "red":
    red = True
  try:
    embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title="Block Art", description="Step 1", color=cola)
    embed.add_field(name="Image", value = "Send the image you want to convert into block art\nCommand will be cancelled after 5 minutes if nothing is sent", inline = False)
    embed.set_footer(text="Requested by: {0}".format(ctx.message.author))
    first = await ctx.send(embed=embed)
    msg = await client.wait_for("message", check=is_correct, timeout=300)
  except asyncio.TimeoutError:
    embed = discord.Embed(description="Step 1", color=cola, timestamp=datetime.datetime.utcnow(), title="Block Art")
    embed.add_field(name="Image", value = "Timed out, try running this command again", inline = False)
    embed.set_footer(text="Requested by {0}".format(ctx.message.author))
    await first.edit(embed=embed)
    return
  image = msg.attachments[0].url
  out = convert_image_to_blocks(image, red=red)
  embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title="Block Art", description="{}".format(out), color=cola)
  embed.set_footer(text="Requested by: {0}".format(ctx.message.author))
  await ctx.send(embed=embed)

@client.command(aliases = ["count"])
@commands.cooldown(1, 5, commands.BucketType.user)
async def counting(ctx):
  if ctx.message.author.guild_permissions.manage_guild:
    Server.counting_channel(ctx.message.guild, ctx.message.channel)
    embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title="Counting Channel", description="All set up!", color=cola)
    embed.set_footer(text="Requested by: {0}".format(ctx.message.author))
    await ctx.send(embed=embed)
  else:
    await need_perms(ctx, cola)	

@client.remove_command("help")
@client.command(name='help', aliases=['Help', "commands"])
async def help(ctx, *args):
  await ctx.send(embed=await show_help(ctx, args))

async def show_help(ctx, args):
  print(args)
  mesagg = ' '.join(args)
  print (mesagg)
  if mesagg == ('info'):
    embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title='Information Commands', color=cola)
    embed.add_field(name='Info (bot) - Some information about me! :smile:', value='Usage: fi info', inline=False)
    embed.add_field(name='Info (server) - I bet I know more about this server than you', value='Usage: fi serverinfo', inline=False)
    embed.add_field(name='Info (user) - Take a look at your online self or stalk someone else', value='Usage: fi userinfo', inline=False)
    client.appinfo = await client.application_info()
    embed.set_author(name="Fiona - Here's the invite link!", icon_url=client.appinfo.owner.avatar_url, url="https://discord.com/api/oauth2/authorize?client_id=736372330644897893&permissions=8&scope=bot%20applications.commands")
  elif mesagg == ('tools'):
    embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title='Tool Commands', color=cola)
    embed.add_field(name='8ball - Answers to your futile questions :8ball:', value='Usage: fi 8ball <question>', inline=False)
    embed.add_field(name='Say - I say what you say',value='Usage: fi say <message>', inline=False)
    embed.add_field(name='Trivia - Ahaha! test out your knowledge!', value='Usage: fi trivia', inline=False)
    embed.add_field(name='Sudoku - Generates solutions to sudokus', value='Usage: fi sudoku', inline=False)
    embed.add_field(name='Poll - Create a poll with me because why not', value='Usage: fi poll<1/2> <idea>', inline=False)
    embed.add_field(name='BMI check - Check if your weight is healthy', value='Usage: fi bmi', inline=False)
    embed.add_field(name='Definitions - Define a word with me', value='Usage: fi define <word>', inline=False)			
    embed.add_field(name='Synonyms - Find some synonyms with me', value='Usage: fi synonyms <word>', inline=False)
    embed.add_field(name='Check Word - Check a word with me', value='Usage: fi checkword <word>', inline=False)
    embed.add_field(name='Help - Gives this AWESOME menu :sunglasses:', value='Usage: fi help', inline=False)
    embed.add_field(name='Purge - Deletes messages in a quick second', value='Usage: fi purge <number>', inline=False)
    embed.add_field(name='Ascii - Generates ascii art from an image', value='Usage: fi ascii <dark/light>', inline=False)
    embed.add_field(name='Block - Generates block art from an image', value='Usage: fi block <red>', inline=False)
    client.appinfo = await client.application_info()
    embed.set_author(name="Fiona - Here's the invite link!", icon_url=client.appinfo.owner.avatar_url, url="https://discord.com/api/oauth2/authorize?client_id=736372330644897893&permissions=8&scope=bot%20applications.commands")
  elif mesagg == ('social'):
    embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title='Social Commands', color=cola)
    embed.add_field(name='Post - Make a new post', value='Usage: fi post', inline=False)
    embed.add_field(name='Bio - Update your bio!', value='Usage: fi bio', inline=False)
    embed.add_field(name="Gallery - Take a look at someone's posts!", value='Usage: fi gallery <@user> <page number>', inline=False)
    embed.add_field(name='Follow - Follow someone', value='Usage: fi follow <user>', inline=False)
    embed.add_field(name="Followers - See who's following you", value='Usage: fi followers', inline=False)
    embed.add_field(name="Following - See who you're following", value='Usage: fi following', inline=False)
    client.appinfo = await client.application_info()
    embed.set_author(name="Fiona - Here's the invite link!", icon_url=client.appinfo.owner.avatar_url, url="https://discord.com/api/oauth2/authorize?client_id=736372330644897893&permissions=8&scope=bot%20applications.commands")
  elif mesagg == ('economy'):
    embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title='Economy Commands', color=cola)
    embed.add_field(name='Leaderboard - A cool board for people with lots of points', value='Usage: fi lb', inline=False)
    embed.add_field(name='Daily - Claim you daily points!', value='Usage: fi daily', inline=False)
    embed.add_field(name="Gallery - Take a look at someone's posts!", value='Usage: fi gallery <@user> <page number>', inline=False)
    embed.add_field(name='Follow - Follow someone', value='Usage: fi follow <user>', inline=False)
    embed.add_field(name="Followers - See who's following you", value='Usage: fi followers', inline=False)
    embed.add_field(name="Following - See who you're following", value='Usage: fi following', inline=False)
    client.appinfo = await client.application_info()
    embed.set_author(name="Fiona - Here's the invite link!", icon_url=client.appinfo.owner.avatar_url, url="https://discord.com/api/oauth2/authorize?client_id=736372330644897893&permissions=8&scope=bot%20applications.commands")
  else:
    embed = discord.Embed(timestamp=datetime.datetime.utcnow(), title='Command Categories', color=cola)
    embed.add_field(name='Info - fi help info', value='Some things about me, you, and the server', inline=False)
    embed.add_field(name='Social - fi help social', value='Update your profile, follow your friends and more!', inline=False)
    embed.add_field(name='Tools - fi help tools', value="Helpful when combatting boredom", inline=False)
    client.appinfo = await client.application_info()
    embed.set_author(name="Fiona - Here's the invite link!", icon_url=client.appinfo.owner.avatar_url, url="https://discord.com/api/oauth2/authorize?client_id=736372330644897893&permissions=8&scope=bot%20applications.commands")
  return embed

keep_alive()
client.run("NzM2MzcyMzMwNjQ0ODk3ODkz.Xxt2LA.omHOSrD8uMfkqVFVT3g-gktytjA")