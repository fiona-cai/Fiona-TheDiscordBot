__title__ = "symspellpy"
__description__ = 'Python SymSpell'
__url__ = "https://github.com/mammothb/symspellpy"
__version__ = "6.7.0"
__author__ = "mmb L"
__author_email__ = "mammothb@hotmail.com"
__license__ = "MIT"
